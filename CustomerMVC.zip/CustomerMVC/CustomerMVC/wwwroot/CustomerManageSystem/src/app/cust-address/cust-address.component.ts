import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';

//import { CustomerAddress } from './CustAddress.Model';

@Component({
  selector: 'app-cust-address',
  templateUrl: './cust-address.component.html',
  styleUrls: ['./cust-address.component.css']
})
export class CustAddressComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  
}
