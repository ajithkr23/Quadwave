﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CustomerManagementSystemApi.Migrations
{
    public partial class AddCust : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("insert into Customers values('Ajith','K R','5/12/2022 14:03:02')");
            migrationBuilder.Sql("insert into Customers values('Deepika','S R','5/15/2022 16:30:02')");
            migrationBuilder.Sql("insert into Customers values('Renuka','Yatagi','5/19/2022 13:25:30')");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
