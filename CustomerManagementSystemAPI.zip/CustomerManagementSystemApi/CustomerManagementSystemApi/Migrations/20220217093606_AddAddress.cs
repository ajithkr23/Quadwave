﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CustomerManagementSystemApi.Migrations
{
    public partial class AddAddress : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("Insert into CustomerAddresses values('2','India','Mysore','Bogadi','9612501248')");
            migrationBuilder.Sql("Insert into CustomerAddresses values('1','India','Mysore','KG Koppalu','8545714585')");
            migrationBuilder.Sql("Insert into CustomerAddresses values('3','India','Mysore','Dattagalli','9712501256')");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
