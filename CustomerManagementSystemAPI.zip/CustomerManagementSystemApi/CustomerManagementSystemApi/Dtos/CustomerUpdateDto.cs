﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerManagementSystemApi.Dtos
{
    public class CustomerUpdateDto
    {
        public string FirstName { set; get; }
        public string LastName { set; get; }
    }
}
