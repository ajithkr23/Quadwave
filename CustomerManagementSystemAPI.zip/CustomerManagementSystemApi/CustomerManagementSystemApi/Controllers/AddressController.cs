﻿using AutoMapper;
using CustomerManagementSystemApi.Data;
using CustomerManagementSystemApi.Dtos;
using CustomerManagementSystemApi.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerManagementSystemApi.Controllers
{
    [ApiController]
    [Route("api/[Controller]")]
    public class AddressController : Controller
    {
        private readonly ICustomer _info;
        private readonly IMapper _mapper;

        public AddressController(ICustomer info,IMapper mapper)
        {
            _info = info;
            _mapper = mapper;
        }
        [HttpGet("{Id}")]
        public ActionResult<CustAddressReadDto> GetAddressByID(int Id)
        {
            var Addr = _info.GetCustomerAddress(Id);
            return Ok(_mapper.Map<CustAddressReadDto>(Addr));
        }
        [HttpGet]
        public ActionResult<IEnumerable<CustAddressReadDto>> GetAddress()
        {
           var Add= _info.GetCustAddress();
            return Ok(_mapper.Map<List<CustAddressReadDto>>(Add));
        }
        [HttpPost]
        public ActionResult<CustAddressCreateDto> CreateCustAddress(CustAddressCreateDto custAddressCreateDto)
        {
            if (custAddressCreateDto != null)
            {
                var newAdd = _mapper.Map<CustomerAddress>(custAddressCreateDto);
                _info.CreateAddress(newAdd);
                return Ok(newAdd);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPut("{Id}")]
        public ActionResult<CustAddressUpdateDto> UpdateCustAddress(CustAddressUpdateDto custAddressUpdateDto, int Id)
        {
            var AddID = _info.GetCustomerAddress(Id);
            if (AddID != null)
            {
                _mapper.Map(custAddressUpdateDto, AddID);
                _info.UpdateAddress(AddID);
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }
        [HttpDelete("{Id}")]
        public ActionResult<CustAddressDeleteDto> DeleteCustAddress(CustAddressDeleteDto custAddressDeleteDto, int Id)
        {
            var AddId = _info.GetCustomerAddress(Id);
            if (AddId != null)
            {
                _mapper.Map(custAddressDeleteDto, AddId);
                _info.DeleteAddress(AddId);
                return Ok();
            }
            else
            {
                return NotFound();

            }
        }

    }
}
