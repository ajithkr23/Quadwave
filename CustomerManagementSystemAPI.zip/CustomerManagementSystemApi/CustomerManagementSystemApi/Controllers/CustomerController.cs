﻿using AutoMapper;
using CustomerManagementSystemApi.Data;
using CustomerManagementSystemApi.Dtos;
using CustomerManagementSystemApi.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerManagementSystemApi.Controllers
{
    [ApiController]
    [Route("api/[Controller]")]
    public class CustomerController : Controller
    {
        private readonly ICustomer _info;
        private readonly IMapper _mapper;

        public CustomerController(ICustomer info,IMapper mapper)
        {
            _info = info;
            _mapper = mapper;
        }

        [HttpGet("{Id}")]
        public ActionResult<CustomerReadDto> GetCusByID(int Id)
        {
            var cust = _info.GetCustomer(Id);
            return Ok(_mapper.Map<CustomerReadDto>(cust));
        }

        [HttpGet]
        public ActionResult<IEnumerable<CustomerReadDto>> GetCustomerList()
        {
            var cust = _info.GetCustomers();
            return Ok(_mapper.Map<List<CustomerReadDto>>(cust));
        }
        [HttpPost]
        public ActionResult<CustomerCreateDto> CreateCustomer(CustomerCreateDto customerCreateDto)
        {
            if(customerCreateDto != null)
            {
                var newCust = _mapper.Map<Customer>(customerCreateDto);
                _info.CreateCustomer(newCust);
                return Ok(newCust);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPut("{Id}")]
        public ActionResult<CustomerUpdateDto> UpdateCustomer(CustomerUpdateDto customerUpdateDto, int Id)
        {
            var CustId = _info.GetCustomer(Id);
            if(CustId!= null)
            {
                _mapper.Map(customerUpdateDto, CustId);
                _info.UpdateCustomer(CustId);
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }
        [HttpDelete("{Id}")]
        public ActionResult<CustomerDeleteDto> DeleteCustomer(CustomerDeleteDto customerDeleteDto,int Id)
        {
            var CustId = _info.GetCustomer(Id);
            if (CustId != null)
            {
                _mapper.Map(customerDeleteDto, CustId);
                _info.DeleteCustomer(CustId);
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }
    }
}
