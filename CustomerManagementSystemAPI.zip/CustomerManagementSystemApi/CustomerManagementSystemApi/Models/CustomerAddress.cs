﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerManagementSystemApi.Models
{
    public class CustomerAddress
    {
        public int Id { get; set; }
        public int CustomerId { set; get; }
        public string Country { set; get; }
        public string City { set; get; }
        public string StreetAddress { set; get; }
        public string Phone { set; get; }

        public Customer Customers { set; get; }
    
    }
}
