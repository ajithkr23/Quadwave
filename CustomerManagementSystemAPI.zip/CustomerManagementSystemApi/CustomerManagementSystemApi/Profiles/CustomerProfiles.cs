﻿using AutoMapper;
using CustomerManagementSystemApi.Dtos;
using CustomerManagementSystemApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerManagementSystemApi.Profiles
{
    public class CustomerProfiles:Profile
    {
        public CustomerProfiles()
        {
            CreateMap<CustomerCreateDto, Customer>();
            CreateMap<Customer, CustomerReadDto>();
            CreateMap<CustomerUpdateDto, Customer>();
            CreateMap<CustomerDeleteDto, Customer>();
            CreateMap<CustomerAddress, CustAddressReadDto>();
            CreateMap<CustAddressCreateDto, CustomerAddress>();
            CreateMap<CustAddressUpdateDto, CustomerAddress>();
            CreateMap<CustAddressDeleteDto, CustomerAddress>();
        }
    }
}
