﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CustomerManagementSystemApi.Models;
using Microsoft.EntityFrameworkCore;

namespace CustomerManagementSystemApi.Data
{
    public class CustomerContext:DbContext
    {
        public CustomerContext(DbContextOptions<CustomerContext> opt) : base(opt)
        { 

        }
        public DbSet<Customer> Customers { set; get; }
        public DbSet<CustomerAddress> CustomerAddresses { set; get; }
    }
}
