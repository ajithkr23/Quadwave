﻿using CustomerManagementSystemApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerManagementSystemApi.Data
{
   public interface ICustomer
    {
        public Customer GetCustomer(int Id);
        public List<Customer> GetCustomers();

        public Customer CreateCustomer(Customer c);
        public void UpdateCustomer(Customer c);
        public void DeleteCustomer(Customer c);

        public List<CustomerAddress> GetCustAddress();
        public CustomerAddress GetCustomerAddress(int Id);
        public CustomerAddress CreateAddress(CustomerAddress Cd);
        public void UpdateAddress(CustomerAddress Cd);
        public void DeleteAddress(CustomerAddress Cd);

    }
}
