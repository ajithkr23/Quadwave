﻿using CustomerManagementSystemApi.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerManagementSystemApi.Data
{
    public class CustomerInfo : ICustomer
    {
        private readonly CustomerContext _context;

        public CustomerInfo(CustomerContext context)
        {
            _context = context;
        }
        public Customer GetCustomer(int Id)
        {
            var cust = _context.Customers.SingleOrDefault(m => m.CustomerId == Id);
            return cust;
        }
        public List<Customer> GetCustomers()
        {
            var custm = _context.Customers.ToList();
            return custm;
        }

        public Customer CreateCustomer(Customer c)
        {
            _context.Customers.Add(c);
            _context.SaveChanges();
            return c;

        }
        public void UpdateCustomer(Customer c)
        {
            _context.SaveChanges();
        }
        public void DeleteCustomer(Customer c)
        {
            _context.Remove(c);
            _context.SaveChanges();

        }
        public List<CustomerAddress> GetCustAddress()
        {
            var Add = _context.CustomerAddresses.ToList();
            return Add;
        }
        public CustomerAddress GetCustomerAddress(int Id)
        {
            var custAdd = _context.CustomerAddresses.SingleOrDefault(m => m.Id == Id);
            return custAdd;
        }
        public CustomerAddress CreateAddress(CustomerAddress Cd)
        {
            _context.CustomerAddresses.Add(Cd);
            _context.SaveChanges();
            return (Cd);
        }
        public void UpdateAddress(CustomerAddress Cd)
        {
            _context.SaveChanges();
        }
        public void DeleteAddress(CustomerAddress Cd)
        {
            _context.Remove(Cd);
            _context.SaveChanges();
        }

    }
}
